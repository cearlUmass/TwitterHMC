import csv
import tweepy as tw
import os
import pickle
from dotenv import load_dotenv

# CONSTANTS
load_dotenv()
auth = tw.OAuthHandler(os.getenv('CONSUMER_KEY'), os.getenv('CONSUMER_SECRET'))  # << key/secret goes here
auth.set_access_token(os.getenv('ACCESS_TOKEN'), os.getenv('ACCESS_TOKEN_SECRET'))  # << Access_token/secret goes here
api = tw.API(auth, wait_on_rate_limit=True)
num_followers = 1


def filterUserData(unfiltered_data, actor_name):
    user_fields = [
        'screen_name',
        'id',
        'followers_count',
        'friends_count',
        'created_at',
        'time_zone',
        'statuses_count',
        'protected',
        'verified',
        'default_profile',
        'default_profile_image',
        'withheld_in_countries',
        'derived'
    ]

    # Add desired fields
    filtered_data = {}
    for field in user_fields:
        try:
            filtered_data[field] = unfiltered_data._json[field]
        except KeyError as e:
            print("COULD NOT GET KEY:", field, "FOR USER", filtered_data['screen_name'])
    filtered_data["follows"] = [actor_name]

    return filtered_data


if __name__ == '__main__':
    # Retrieve list of political actors
    with open('Data/master_set.csv', 'r') as csvfile:
        reader = csv.reader(csvfile)
        actors = list(reader)

    # Iterate through all followers of a given political actor
    # followers = { follower_name : { Data : ..., follows : [list of actors user is following] }
    followers = {}
    for actor in actors:
        actor_name = actor[0]

        # Try catch in case the actors name cannot be retrieved
        try:

            # Iterate through followers of actor
            for follower in tw.Cursor(api.followers, actor_name).items(num_followers):
                follower_name = follower.screen_name

                # If follower is already in dict, append the actor
                print(follower)
                if follower_name in followers:
                    followers[follower_name]['follows'].append(actor_name)

                # Otherwise add follower data to dict
                else:
                    followers[follower_name] = filterUserData(follower, actor_name)

        except tw.error.TweepError as e:
            print("ERROR RETRIEVING ACTOR:", e, "\nACCOUNT:", actor_name)

    with open('Data/Follower Data.pkl', 'wb') as data_file:
        pickle.dump(followers, data_file, pickle.HIGHEST_PROTOCOL)